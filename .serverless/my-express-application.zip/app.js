"use strict";
const serverless = require('serverless-http')
const express = require('express')
const app = express()
const cors = require('cors')
// const dotenv = require('dotenv').config()
// const PORT = process.env.PORT
const errorHandler = require('./middlewares/errorHandler')
const userRouter = require('./routes/user')
const folderRoute = require('./routes/folder')
// const mongoose = require('mongoose')



app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: false }))

// mongoose.connect("mongodb+srv://cvarun98:gyroscope@mydata.ykwgpuq.mongodb.net/")

app.use('/api/user', userRouter)
app.use('/', (req, res, next) => {
    console.log('checkin')
    next()
})
// app.use('/api/folder', folderRoute)
app.use(errorHandler)

module.exports.handler = serverless(app);

// app.listen(PORT, () => {
//     try {
//         console.log(`SERVER RUNNING ON PORT ${PORT}`)
//     } catch (error) {
//         console.log(`ERROR WHILE STARTING SERVER ${error}`)
//     }
// })
